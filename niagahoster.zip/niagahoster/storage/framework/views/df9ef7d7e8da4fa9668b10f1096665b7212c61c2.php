<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.templates.default','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('templates.default'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('pretitle', null, []); ?> Data Book <?php $__env->endSlot(); ?>
     <?php $__env->slot('title', null, []); ?> Books <?php $__env->endSlot(); ?>
     <?php $__env->slot('page_action', null, []); ?> 
        <a href="<?php echo e(route('books.create')); ?>" class="btn btn-primary">Add Book</a>
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('extraStyles', null, []); ?> 
        <link href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css" rel="stylesheet">
        <link rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.4.18/sweetalert2.min.css"
            integrity="sha512-CJ5goVzT/8VLx0FE2KJwDxA7C6gVMkIGKDx31a84D7P4V3lOVJlGUhC2mEqmMHOFotYv4O0nqAOD0sEzsaLMBg=="
            crossorigin="anonymous" referrerpolicy="no-referrer" />
     <?php $__env->endSlot(); ?>

    <div class="row row-cards">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-vcenter card-table" id="dataTable">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Title</th>
                                    <th>Cover</th>
                                    <th>Published</th>
                                    <th>Category</th>
                                    <th>Publisher</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
     <?php $__env->slot('extraScripts', null, []); ?> 
        <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
        <script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>

        <script>
            $(function() {
                $('#dataTable').DataTable({
                    processing: true,
                    serverSide: true,
                    ajax: '<?php echo route('books.index'); ?>', // memanggil route yang menampilkan data json
                    columns: [{ // mengambil & menampilkan kolom sesuai tabel database
                        data: 'DT_RowIndex',
                        name: 'id'
                    }, {
                        data: 'title',
                        name: 'title'
                    }, {
                        data: 'cover',
                        name: 'cover'
                    }, {
                        data: 'published_at',
                        name: 'published_at'
                    }, {
                        data: 'category.name',
                        name: 'category_name'
                    }, {
                        data: 'publisher.name',
                        name: 'publisher_name'
                    }, {
                        data: 'action',
                        name: 'action'
                    }, ]
                });
            });
        </script>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.4.18/sweetalert2.min.js"
            integrity="sha512-98hK38IvWQC069FFbq/la6NaBj4TGplZ118B+bFVOxsBQQL4EqKUWw9JkNh8Lem7FCGkLCxgr81q+/hRIemJCw=="
            crossorigin="anonymous" referrerpolicy="no-referrer"></script>
        <script>
            $('#dataTable').on('click', 'button#delete', function(e) {
                e.preventDefault();
                var id = $(this).data('id');

                Swal.fire({
                    title: 'Kamu yakin hapus data ini?',
                    text: "Data yang dihapus tidak bisa dikembalikan!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Ok, Delete!',
                    cancelButtonText: 'Cancel',
                }).then((result) => {
                    if (result.value) {
                        $.ajax({
                            type: 'DELETE',
                            url: '/books/' + id,
                            data: {
                                'id': id,
                                '_token': "<?php echo e(csrf_token()); ?>"
                            },
                            success: function(response) {
                                if (response.error) {
                                    Swal.fire(
                                        'Gagal menghapus data!', response.error, 'error'
                                    )
                                } else {
                                    Swal.fire(
                                        'Dihapus!', 'Data berhasil dihapus.', 'success'
                                    )

                                    location.reload(true);
                                }
                            },
                        });
                    }
                })
            })
        </script>

     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\niagahoster\resources\views/books/index.blade.php ENDPATH**/ ?>