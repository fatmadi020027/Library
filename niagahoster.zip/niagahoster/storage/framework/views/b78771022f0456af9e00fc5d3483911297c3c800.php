<a href="<?php echo e(route('books.edit', $model)); ?>" class="btn btn-info">Edit</a>
<button class="btn btn-danger" data-id="<?php echo e($model->id); ?>" id="delete">Delete</button>
<?php /**PATH C:\xampp\htdocs\niagahoster\resources\views/books/action.blade.php ENDPATH**/ ?>