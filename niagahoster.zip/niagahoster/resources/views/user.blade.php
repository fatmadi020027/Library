<x-templates.default>
     <x-slot:page_action>
        <button class="btn btn-primary">Add User</button>
    </x-slot>

    <h1>User</h1>
</x-templates.default>
