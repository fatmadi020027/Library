<x-templates.default>
    <h1>Homepage</h1>
</x-templates.default>
