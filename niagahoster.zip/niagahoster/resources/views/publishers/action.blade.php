<a href="{{ route('publishers.edit', $model) }}" class="btn btn-info">Edit</a>
<button data-id="{{ $model->id }}" id="delete" class="btn btn-danger">Delete</button>
