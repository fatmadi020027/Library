<a href="{{ route('books.edit', $model) }}" class="btn btn-info">Edit</a>
<button class="btn btn-danger" data-id="{{ $model->id }}" id="delete">Delete</button>
